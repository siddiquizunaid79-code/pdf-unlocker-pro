PDF Unlocker Pro — backend starter

Features:
- /unlock removes open-password protection when the correct password is provided.
- /recover tests up to 100 candidate passwords supplied by the user, one per line.
- Temporary uploaded files are deleted after each request; upload limit is 20 MB.

Limits:
- It cannot magically discover an unknown password.
- Recovery only tests the candidates supplied; no guarantee of success.
- This backend is NOT yet connected to the existing Netlify frontend.

Deploy:
1. Create a GitHub repository and upload app.py, requirements.txt, render.yaml.
2. On Render, create a Web Service from that repository.
3. Build command: pip install -r requirements.txt
4. Start command: uvicorn app:app --host 0.0.0.0 --port $PORT
5. After deploy, open the service URL; it should show {"status":"ok",...}.
6. The frontend still needs code to call this backend.

Privacy: Use only PDFs you own or are authorized to access. Do not upload sensitive files to services you do not control. Hosting providers may retain operational logs. Before public launch, add rate limits, abuse controls, and a privacy notice.
